# lowerkase j — The Celestial Archive

A minimal artist landing page with discography and merch pages, revised to the user's October 15, 2026 direction. Local review build; not published.

## Run locally

Requires Node.js 20.9+ and pnpm.

```sh
pnpm install --frozen-lockfile
pnpm build
pnpm start
```

Open http://127.0.0.1:3000. The discography page is at /discography and the merch page is at /merch. Development uses webpack; set WATCHPACK_POLLING=true if required by restricted macOS filesystem watchers.

Bundled Node: /Users/aimachine/.cache/codex-runtimes/codex-primary-runtime/dependencies/node/bin/node. Bundled pnpm: /Users/aimachine/.cache/codex-runtimes/codex-primary-runtime/dependencies/bin/fallback/pnpm. Put the Node binary directory on PATH when running pnpm.

## Current scope

- Homepage: original snow hero, artist identity, compact ANGEL upcoming-project note and all five supplied social destinations.
- Header: Home, Discography and Merch, visible on desktop and mobile. No menu drawer or extra section navigation.
- Discography: 3 projects and 35 public SoundCloud uploads, with original artwork, expandable project tracklists and direct listening links. Automatically refreshes from public SoundCloud pages at most once every five minutes. An open visible tab also refreshes every five minutes.
- Merch: a separate coming-soon page, with an Instagram announcement link and typographic orbit illustration. No invented products, prices or release dates.
- Porcelain background and dark text across both pages; compact footer.
- Sound archive, image archive, journal/transmissions, about section, newsletter teaser and large footer removed.
- Original reference images remain in the source, but only the requested snow hero is displayed.
- Next.js App Router, React, TypeScript, responsive CSS, native links, reduced-motion support and review noindex metadata.

## Review boundaries

No CMS, Shopify, checkout, newsletter, analytics or media-player integration. No data collection. No production domain or DNS changes. The latest request supersedes the original multi-page archive brief; a discography page has since been requested and implemented; journal and biography pages remain outside scope.

See docs/DISCOVERY.md for historical references and asset provenance, docs/ARCHITECTURE.md for the current architecture, and docs/QA.md for current verification. Review captures are in the neighboring outputs/review directory.

## Future launch

Use this directory as a Vercel Next.js project root. Install with pnpm install --frozen-lockfile and build with pnpm build. Before public launch, confirm the final origin and metadata, supply approved sharing art, and remove review noindex when authorized. Future merch requires real product data and a configured commerce provider before purchase actions are enabled. For production automatic sync, run on a Node host with a persistent cache volume (see below).

## Automatic SoundCloud updates

The discography checks public SoundCloud tracks, albums, playlists and RSS on demand, at most once every five minutes per server process. Open visible discography tabs refresh every five minutes and when returning to the tab. New public uploads are added automatically; the last successful catalog remains visible during SoundCloud failures. No audio files or credentials are imported.

Discovery uses the latest public profile uploads and RSS. This account's RSS currently contains no tracks. The public profile exposes the latest 10 uploads; more than 10 new uploads between successful syncs may require a full catalog refresh. New projects with unresolved track IDs preserve the last complete catalog until their tracks can be discovered. SoundCloud public-page format changes can interrupt this integration. For dependable large-batch publishing, enable inclusion of all uploads in SoundCloud RSS or connect an official SoundCloud API application before launch.

The discovered catalog is persisted to .data/soundcloud-catalog.json by default. Set SOUNDCLOUD_CACHE_DIR to a writable persistent directory in production. A read-only or ephemeral host needs a durable store adapter; do not deploy this configuration to Vercel assuming filesystem persistence. The bundled content/discography.json is the first-launch/offline fallback. Persistence failure uses a process-local memory cache and logs a warning.

To refresh the bundled fallback manually, verify any newly discovered URLs in content/soundcloud-sources.json and run node scripts/import-soundcloud.mjs. Rebuild afterward. This manual step is not needed for normal new uploads discovered by the running site.
