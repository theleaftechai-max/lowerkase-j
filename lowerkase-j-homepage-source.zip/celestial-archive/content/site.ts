/** User-supplied URLs. Verification status is documented in docs/DISCOVERY.md. */
export const socialLinks = [
  { name: 'Instagram', url: 'https://www.instagram.com/lowerkase.j', handle: '@lowerkase.j' },
  { name: 'X', url: 'https://x.com/lowerkasej', handle: '@lowerkasej' },
  { name: 'SoundCloud', url: 'https://soundcloud.com/lowerkasej', handle: 'Listen on SoundCloud' },
  { name: 'YouTube', url: 'https://youtube.com/@lowerkasej', handle: '@lowerkasej' },
  { name: 'TikTok', url: 'https://www.tiktok.com/@lowerkase.j', handle: '@lowerkase.j' },
] as const;
export const upcomingProject = { title: 'ANGEL', status: 'Upcoming project' };
