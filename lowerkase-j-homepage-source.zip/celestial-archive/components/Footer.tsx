export default function Footer() {
  return <footer className="site-footer micro"><span>© {new Date().getFullYear()} LOWERKASE J</span><span>THE CELESTIAL ARCHIVE</span></footer>;
}
