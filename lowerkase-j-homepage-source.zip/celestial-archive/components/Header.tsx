import Link from 'next/link';

export default function Header({ current = 'home' }: { current?: 'home' | 'discography' | 'merch' }) {
  return (
    <header className="site-header">
      <Link href="/" className="brand" aria-label="lowerkase j home">
        <span className="brand-symbol" aria-hidden="true">j<span /></span>
        <span className="micro">LOWERKASE J<br /><span className="muted">THE CELESTIAL ARCHIVE</span></span>
      </Link>
      <nav aria-label="Main navigation">
        <Link href="/" aria-current={current === 'home' ? 'page' : undefined}>Home</Link>
        <Link href="/discography" aria-current={current === 'discography' ? 'page' : undefined}>Discography</Link>
        <Link href="/merch" aria-current={current === 'merch' ? 'page' : undefined}>Merch <span aria-hidden="true">↗</span></Link>
      </nav>
    </header>
  );
}
