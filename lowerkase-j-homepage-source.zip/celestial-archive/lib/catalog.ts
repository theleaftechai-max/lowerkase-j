import 'server-only';
import fs from 'node:fs/promises';
import path from 'node:path';
import snapshot from '@/content/discography.json';
import { syncCatalog } from './soundcloud-sync.mjs';

export type Catalog = typeof snapshot;
const INTERVAL_MS = 5 * 60 * 1000;
let current: Catalog = snapshot;
let checkedAt = 0;
let initialized = false;
let pending: Promise<Catalog> | undefined;
const cacheFile = path.join(process.env.SOUNDCLOUD_CACHE_DIR ?? path.join(process.cwd(), '.data'), 'soundcloud-catalog.json');

async function readPage(url: string): Promise<string | null> {
  for (let redirects = 0; redirects < 4; redirects++) {
    const parsed = new URL(url);
    const allowed = (parsed.origin === 'https://soundcloud.com' && parsed.pathname.startsWith('/lowerkasej/')) || url === 'https://feeds.soundcloud.com/users/soundcloud:users:251726301/sounds.rss';
    if (!allowed) throw Error('Unexpected SoundCloud URL');
    const response = await fetch(url, { cache: 'no-store', signal: AbortSignal.timeout(8000), redirect:'manual' });
    if ([301,302,303,307,308].includes(response.status)) {
      const location = response.headers.get('location');
      if (!location) throw Error('Invalid SoundCloud redirect');
      url = new URL(location,url).href;
      continue;
    }
    if (response.status === 404 || response.status === 410) return null;
    if (!response.ok) throw Error(`SoundCloud unavailable (${response.status})`);
    return response.text();
  }
  throw Error('Too many SoundCloud redirects');
}

export async function getCatalog(): Promise<Catalog> {
  if (pending) return pending;
  if (initialized && Date.now() - checkedAt < INTERVAL_MS) return current;
  pending = (async () => {
    if (!initialized) {
      try {
        const saved: Catalog = JSON.parse(await fs.readFile(cacheFile,'utf8'));
        if (saved.source === snapshot.source && Array.isArray(saved.tracks) && Array.isArray(saved.projects) && Date.parse(saved.importedAt) > Date.parse(snapshot.importedAt)) current = saved;
      } catch { /* The bundled catalog handles first launch and read failures. */ }
      initialized = true;
    }
    try {
      const fresh = await syncCatalog(current, readPage) as Catalog;
      // Persist discovery history so future refreshes retain previously found uploads.
      try {
        await fs.mkdir(path.dirname(cacheFile), { recursive:true });
        await fs.writeFile(cacheFile+'.tmp', JSON.stringify(fresh));
        await fs.rename(cacheFile+'.tmp',cacheFile);
      } catch { console.warn('SoundCloud catalog persistence unavailable; using memory cache. Configure SOUNDCLOUD_CACHE_DIR on a persistent volume for production.'); }
      current = fresh;
    } catch { console.warn('SoundCloud refresh failed; retaining the last successful catalog.'); }
    checkedAt = Date.now();
    return current;
  })();
  try { return await pending; } finally { pending = undefined; }
}
