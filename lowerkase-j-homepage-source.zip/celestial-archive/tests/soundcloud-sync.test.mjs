import test from 'node:test';
import assert from 'node:assert/strict';
import { syncCatalog, trackUrls, PROFILE } from '../lib/soundcloud-sync.mjs';
const seed = {source:PROFILE, importedAt:'2026-01-01T00:00:00Z', tracks:[{id:1,title:'Existing track',url:PROFILE+'/existing',artwork:null,uploadedAt:'2025-01-01T00:00:00Z',durationMs:1000,releaseDate:null}], projects:[]};
function track(id, title, overrides={}) {
  return `<script>window.__sc_hydration = ${JSON.stringify([{hydratable:'sound',data:{id,title,user_id:251726301,public:true,sharing:'public',permalink_url:PROFILE+(id===1?'/existing':id===2?'/new-upload':'/rss-upload'),full_duration:120000,created_at:id===1?'2025-01-01T00:00:00Z':'2026-01-01T00:00:00Z',release_date:null,...overrides}}])};</script>`;
}
function reader(options={}) {
  return async url => {
    if (url.endsWith('/tracks')) return '<a href="/lowerkasej/new-upload">New upload</a><a href="/other-artist/repost">Repost</a><a href="/lowerkasej/likes">Likes</a>';
    if (url.endsWith('/albums') || url.endsWith('/sets')) return '<html></html>';
    if (url.includes('feeds.soundcloud.com')) return options.rss??'<rss><channel></channel></rss>';
    if (url.endsWith('/existing')) return options.removed?null:track(1,'Existing track');
    if (url.endsWith('/new-upload')) { if(options.fail) throw Error('Unavailable'); return track(2,'New public upload',options.data); }
    if (url.endsWith('/rss-upload')) return track(3,'RSS upload');
    throw Error('Unexpected URL '+url);
  };
}
test('new public uploads appear without changing the bundled catalog',async()=>{
  const result=await syncCatalog(seed,reader());
  assert.equal(result.tracks.length,2);
  assert.equal(result.tracks[0].title,'New public upload');
  assert.equal(seed.tracks.length,1);
});
test('discovery excludes navigation and other artists',()=>{
  assert.deepEqual(trackUrls('<a href="/lowerkasej/new-upload"></a><a href="/lowerkasej/likes"></a><a href="/elsewhere/track"></a>'),[PROFILE+'/new-upload']);
});
test('private or mismatched-owner uploads are excluded',async()=>{
  assert.equal((await syncCatalog(seed,reader({data:{public:false,sharing:'private'}}))).tracks.length,1);
  assert.equal((await syncCatalog(seed,reader({data:{user_id:123}}))).tracks.length,1);
});
test('removed known tracks are excluded after a successful refresh',async()=>{
  assert.deepEqual((await syncCatalog(seed,reader({removed:true}))).tracks.map(t=>t.id),[2]);
});
test('upstream errors reject the refresh and leave the previous catalog intact',async()=>{
  await assert.rejects(syncCatalog(seed,reader({fail:true})),/Unavailable/);
  assert.equal(seed.tracks[0].title,'Existing track');
});
test('RSS discovers tracks beyond the profile page',async()=>{
  const result=await syncCatalog(seed,reader({rss:`<rss><item><link>${PROFILE}/rss-upload</link></item></rss>`}));
  assert.equal(result.tracks.length,3);
});
test('renamed or rediscovered canonical tracks are deduplicated by ID',async()=>{
  const result=await syncCatalog(seed,reader({data:{id:1,permalink_url:PROFILE+'/existing'}}));
  assert.equal(result.tracks.length,1);
});
test('new public projects are discovered automatically',async()=>{
  const read=reader();
  const result=await syncCatalog(seed,async url=>{
    if(url.endsWith('/albums'))return '<a href="/lowerkasej/sets/new-project">New project</a>';
    if(url.endsWith('/sets/new-project')) return `<script>window.__sc_hydration = ${JSON.stringify([{hydratable:'playlist',data:{id:3,title:'New project',user_id:251726301,public:true,sharing:'public',permalink_url:PROFILE+'/sets/new-project',created_at:'2026-01-01T00:00:00Z',release_date:null,set_type:'ep',tracks:[{id:2}]}}])};</script>`;
    return read(url);
  });
  assert.equal(result.projects[0].title,'New project');
  assert.deepEqual(result.projects[0].trackIds,[2]);
});
