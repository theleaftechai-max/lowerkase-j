/** Refresh the known public catalog. Add newly verified URLs to the source manifest first. */
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const sources = JSON.parse(await fs.readFile(path.join(root, 'content/soundcloud-sources.json'), 'utf8'));
const imageDownloads = new Map();
async function artwork(html) {
  const url = html.match(/<meta property="og:image" content="([^"]+)"/)?.[1];
  if (!url) return null;
  const image = new URL(url);
  if (image.hostname !== 'i1.sndcdn.com' || !image.pathname.startsWith('/artworks-')) return null;
  const name = path.basename(image.pathname);
  if (!/^[a-zA-Z0-9_-]+\.jpg$/.test(name)) throw Error('Unexpected artwork filename');
  if (!imageDownloads.has(url)) imageDownloads.set(url, (async () => {
    const response = await fetch(url);
    if (!response.ok || !response.headers.get('content-type')?.startsWith('image/')) throw Error('Artwork unavailable');
    await fs.writeFile(path.join(root, 'public/releases', name), Buffer.from(await response.arrayBuffer()));
  })());
  await imageDownloads.get(url);
  return { src: '/releases/' + name, sourceUrl: url };
}
async function read(url, hydratable) {
  const u = new URL(url);
  if (u.origin !== 'https://soundcloud.com' || !u.pathname.startsWith('/lowerkasej/')) throw Error('Unexpected catalog URL');
  const response = await fetch(url);
  if (!response.ok) throw Error(`SoundCloud returned ${response.status}: ${url}`);
  const html = await response.text();
  const raw = html.match(/window\.__sc_hydration\s*=\s*(\[[\s\S]*?\]);/);
  if (!raw) throw Error(`No public metadata: ${url}`);
  const data = JSON.parse(raw[1]).find(x => x.hydratable === hydratable)?.data;
  if (!data || data.user_id !== sources.userId || data.public !== true || data.sharing !== 'public') throw Error(`Not a public artist upload: ${url}`);
  return { data, art: await artwork(html) };
}
async function batches(items, fn) {
  const result = [];
  for (let i = 0; i < items.length; i += 4) result.push(...await Promise.all(items.slice(i, i + 4).map(fn)));
  return result;
}
await fs.mkdir(path.join(root, 'public/releases'), { recursive: true });
const tracks = await batches(sources.tracks, async url => {
  const {data, art} = await read(url, 'sound');
  return { id: data.id, title: data.title, url: data.permalink_url, artwork: art, durationMs: data.full_duration ?? data.duration, uploadedAt: data.display_date ?? data.created_at, releaseDate: data.release_date ?? null };
});
const projects = await batches(sources.projects, async url => {
  const {data, art} = await read(url, 'playlist');
  const trackIds = data.tracks.map(t => t.id);
  if (trackIds.length !== data.track_count || trackIds.some(id => !tracks.some(t => t.id === id))) throw Error(`Incomplete project tracks: ${url}`);
  return { id: data.id, title: data.title, url: data.permalink_url, artwork: art, releaseDate: data.release_date ?? null, publishedAt: data.published_at, type: data.set_type === 'ep' ? 'EP' : data.set_type === 'album' ? 'Album' : 'Project', trackIds };
});
tracks.sort((a,b) => b.uploadedAt.localeCompare(a.uploadedAt));
projects.sort((a,b) => (b.releaseDate ?? b.publishedAt).localeCompare(a.releaseDate ?? a.publishedAt));
const catalog = { source: sources.profile, importedAt: new Date().toISOString(), tracks, projects };
// Write only after the entire import succeeds, keeping the last good snapshot on failure.
await fs.writeFile(path.join(root, 'content/discography.json'), JSON.stringify(catalog, null, 2) + '\n');
console.log(`Imported ${tracks.length} public uploads and ${projects.length} projects; ${imageDownloads.size} artworks.`);
