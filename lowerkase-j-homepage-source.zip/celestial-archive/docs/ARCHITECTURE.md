# Current architecture

## Scope

The latest user request replaces the original full archive with a landing page and a separate space for possible merch drops. A discography page was subsequently requested.

| Route | Current behavior |
| --- | --- |
| / | Hero artwork, artist identity, compact ANGEL note and five supplied social links |
| /discography | Automatically refreshed public SoundCloud catalog (initially 3 projects and 35 uploads), with artwork, project tracklists and listening links |
| /merch | Coming-soon merchandise page with a follow link for announcements |

The landing and merch routes are static; discography is a dynamic Next.js App Router page with TypeScript and custom responsive CSS. Shared Header and Footer are server components. Home/Merch use Next Link; outgoing social links open in a new tab with noopener/noreferrer. Discography has a server-side public SoundCloud sync and a small client refresh component. Original hero artwork is delivered by Next Image. Dependencies are fixed by pnpm-lock.yaml.

## Future commerce

When actual drops are approved, use the artist-owned store as the source of truth for product images, variants, prices and stock. Keep the coming-soon state until real inventory and the checkout destination are configured. Test stock, variants and checkout in the provider's test mode before enabling purchases. Store secrets only in the hosting platform.

A CMS, journal, biography, newsletter and video player are outside the revised scope. The earlier proposal for these features is superseded.

## Launch

Confirm an approved hosting destination and final origin, finish sharing metadata, and enable indexing only for the approved public build. No production domain or DNS changes have been made.

## Discography import

content/discography.json contains sanitized public metadata. scripts/import-soundcloud.mjs reads the verified public URLs in content/soundcloud-sources.json, checks ownership and public sharing, resolves all project tracks against the track catalog, and saves original public artwork under public/releases. No audio downloads, login, runtime scraping or live sync. New items require adding their verified URLs and rerunning the importer. Native details elements provide expandable tracklists without client JavaScript.

## Automatic sync supersedes snapshot-only behavior

lib/catalog.ts deduplicates concurrent refreshes, checks at most every five minutes per process, persists the last complete successful catalog, and retains it on upstream failures. lib/soundcloud-sync.mjs discovers public profile and RSS links, validates uploader/public status, merges known discoveries, and refreshes metadata. Remote artwork for future uploads is restricted by Next Image to HTTPS i1.sndcdn.com/artworks-* URLs. CatalogRefresh refreshes visible pages every five minutes and on visibility return.

Use a persistent Node hosting volume via SOUNDCLOUD_CACHE_DIR. Serverless/ephemeral hosting requires a durable storage adapter before production. Public HTML discovery has a latest-10 upload window when RSS is empty; enable SoundCloud RSS inclusion or use an official API app for large-batch completeness. Profile markup changes can cause refresh failures; the last good catalog is retained and server logs report them. New projects are only accepted when all project track IDs are resolved.
