# Discovery and art direction

Audit date: October 15, 2026. Current live reference sites were inspected directly; their current campaigns may change. Original briefing document and user-supplied images govern the build. No historical ChatGPT attachments were automatically available.

## Reference observations

| Reference | Observed behavior | Application to lowerkase j |
| --- | --- | --- |
| [Skaiwater](https://skaiwater.com/) | White, restrained storefront. Shop, tour and listening share the navigation. Artist mark is central. Desktop product rows become two columns on mobile. [Vinyl detail](https://skaiwater.com/products/wonderful-vinyl) offers signed/unsigned variants, multiple images, quantity and cart. | Keep art and physical releases in one world. Keep listening visible. Use actual inventory/variants when connected. |
| [Lexa Gates music](https://www.lexagates.com/music/) | White gallery with a distinctive script mark, large artwork and direct Listen Now actions. A loading screen appeared during initial inspection, then resolved. Desktop layout was visually confirmed; the first mobile capture was obscured by its loader, so a full mobile visual audit is incomplete. | Give every confirmed release one unambiguous listening destination. Preserve artwork prominence without making content depend on an entrance loader. |
| [Malcolm Todd](https://www.malcolmtodd.cool/) | Minimal black page, large artist name, direct Shop/Tour/Listen/Watch actions, campaign poster, album and store links, and additional playful interactions. A cookie notice covers much of the first screen. Mobile viewport was sampled, but the immediate capture retained a scaled desktop arrangement; mobile behavior requires a later revisit for conclusive inspection. | Artist personality can coexist with plain navigation. Keep visitor content available immediately. |
| [Don Toliver](https://dontoliver.com/) | Black release-era storefront with large OCTANE mark, music/tour actions, clothing and physical music in one product collection. Desktop has four product columns; a narrow-width sample shows two-column products and a compact menu/cart. | Use creative-era branding through accents and featured content while commerce remains conventional. Never copy this reference's product inventory into the artist site. |

Product detail behavior was read for Skaiwater; no carts, checkout, accounts, purchases or store state were modified. Don Toliver product detail and Malcolm Todd's external store have not been fully audited. Production domains and the unapproved Higgsfield prototype have not been modified or reused.

## Original visual direction

Porcelain paper (#f1f0ed), soft ink (#202320), slate midnight (#171f25), icy silver blue (#d8e0e7). Oversized tightly set sans-serif artist name contrasts with restrained italic serif lines and monospaced archival metadata. The snow image anchors the entrance. Thin elliptical line work echoes an impression/halo; imagery supplies the texture, without extra grain overlays or generated angels. Page rhythm moves from quiet entrance to a dark sound room, open image gallery, physical-artifact announcement, transmission, artist identity and direct connections.

CSS-only hover and halo transformations keep motion light. Smooth scrolling uses native browser behavior and is disabled under prefers-reduced-motion. No scroll-jacking, audio autoplay, mandatory animation, external font requests, analytics scripts or cookie tracking are included.

## Asset inventory

Source images were copied unaltered; Next Image may generate optimized delivery variants. No supplied originals were edited.

| Supplied filename | Local path | Use and limits |
| --- | --- | --- |
| IMG_2510.jpg | public/artwork/snow.jpg | Homepage entrance. Original square artwork retained, including embedded marks. Not labeled as confirmed ANGEL cover art. |
| 7766DCDD-682B-4AC1-98ED-3382F2C13DA6.jpg | public/artwork/silhouette.jpg | Full image archive object and fullscreen viewing. |
| D993A89C-1589-4247-AE62-A1D9DCA8D374.jpg | public/artwork/blue.jpg | Wide gallery image, preserving atmospheric grain and color. |
| Black_and_White_Sport_Modern_Hoodie.png | public/artwork/angel-study.png | Angel impression displayed as artwork. Filename does not establish a saleable garment; no product was inferred. |

All four came from the user-provided paths under `/Users/aimachine/Downloads/`. Newly authored code graphics: j/halo favicon, typographic mark, CSS elliptical line work. No AI-generated bitmap imagery.

Still unavailable in the workspace, Downloads filename search, or accessible attachment directory: `1080.mp4`, `1080(1).mp4`, `exclusive.mov`, `kiss_of_life.png`. These must be uploaded or supplied as accessible local paths. The prior ChatGPT conversation has not been retrieved and is not presumed available.

## Official URL checks

Direct HTTP checks on October 15 returned HTTP 200 for all five user-supplied social destinations. Public web-reader attempts failed on those profiles, and broad search returned no reliable Spotify/Apple Music match. HTTP reachability does not establish account ownership or verify catalog details.

- Instagram: https://www.instagram.com/lowerkase.j
- X: https://x.com/lowerkasej
- SoundCloud: user-supplied short link redirected to https://soundcloud.com/lowerkasej with sharing parameters; build uses the same destination without tracking parameters.
- YouTube: https://youtube.com/@lowerkasej redirected to https://www.youtube.com/@lowerkasej.
- TikTok: https://www.tiktok.com/@lowerkase.j

No Spotify, Apple Music, release-specific streaming destinations, release dates, tracklists or media embed identifiers have been added.

## Homepage revision — October 15, 2026

The user clarified that the additional supplied imagery was for reference only. The image archive was removed from the homepage, while the snow hero was retained. The sound section now continues the porcelain/ink entrance palette, including its ANGEL announcement panel. Original direction and asset mappings above are historical discovery notes.

## Simplified direction — October 15, 2026

The user requested only the hero and follow links on a landing page, plus a separate page for possible merch drops. This supersedes the original full archive scope. Sound archive, transmissions/journal, about and connect sections have been removed. Home and Merch are the only navigation destinations. The original hero and its compact ANGEL note remain; official social links now sit directly beneath the hero. Merch is a coming-soon page, with no invented products or checkout.

## SoundCloud discography — October 15, 2026

Imported all 35 public uploads observed on https://soundcloud.com/lowerkasej/tracks through normal browser pagination. Public project pages: https://soundcloud.com/lowerkasej/sets/purples-prelude (9 tracks, Project; not labeled an album), https://soundcloud.com/lowerkasej/sets/dennis-rodman (5 tracks, EP), and https://soundcloud.com/lowerkasej/sets/temptations (5 tracks, EP). Public page metadata confirms uploader ID 251726301 and public sharing for every item. Excluded likes/reposts and unrelated accounts. Titles, artwork, duration, upload timestamps, confirmed project release dates and canonical listening links come from those public pages. 19 tracks belong to projects; 16 appear in More tracks. Track years use upload timestamps, and project years use supplied release dates. No private data or audio files are imported.

The page is a local snapshot, not a live sync. scripts/import-soundcloud.mjs refreshes the known URLs in content/soundcloud-sources.json; add newly verified public tracks/projects to that manifest before refreshing. It validates ownership/public status and project completeness, downloads only public artwork, and writes the catalog only after all imports succeed. The generated catalog excludes raw authorization/streaming data from SoundCloud page hydration.

## Automatic updates — October 15, 2026

At the user’s request, the discography now checks SoundCloud at most every five minutes while running. This supersedes the earlier snapshot-only boundary. The public RSS endpoint https://feeds.soundcloud.com/users/soundcloud:users:251726301/sounds.rss currently contains no items, so normal new-upload discovery uses the public tracks page. The verified initial catalog remains the fallback, and successful discoveries persist in the configured cache directory. See README for hosting and latest-10 discovery limits.
