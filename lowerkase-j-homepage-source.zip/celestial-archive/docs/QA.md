# Current verification — October 15, 2026

Scope: minimal landing page, discography and coming-soon merch page. Earlier archive/gallery checks are superseded.

- Final production build passed, including TypeScript validation. Home and Merch are static; Discography renders dynamically.
- Imported all 35 observed public SoundCloud uploads and 3 projects; ownership, public status, canonical links and local artwork verified. 19 tracks are in projects, 16 in More tracks.
- Live automatic sync returned 35 tracks and 3 projects. A production HTTP request returned the discography and persisted a new successful catalog under .data/soundcloud-catalog.json.
- Eight sync tests passed: new uploads, profile-link exclusions, private/wrong-owner exclusions, removed uploads, upstream failure preservation, RSS discoveries, canonical ID deduplication and new project discovery. New-upload tests use fixtures; no music was uploaded to the artist account.
- Desktop (1280 × 900) and mobile (390 × 844) discography layouts visually inspected. Mobile DOM reported no horizontal overflow.
- Home navigation opens Discography. Native project tracklist expanded and displayed 9 entries; Enter collapsed it. The other two projects each contain 5 entries.
- Five-minute visible-tab refresh and visibility-return refresh are implemented; no full five-minute browser waiting session was run. Server refreshes are request-driven and throttled per process.
- Full-page captures saved to outputs/review/discography-desktop.png and discography-mobile.png. The viewport override was reset afterward.
- Previous landing/merch desktop and mobile checks passed; the latest navigation adds Discography and fits the mobile header.
- Native links, semantic sections, image alt text, skip link, focus styles and reduced-motion CSS are present. No separate screen-reader, OS reduced-motion or cross-browser certification was run.
- No public deployment, production domain changes, CMS, checkout or newsletter integration.

## Automatic-update limits

Use a persistent Node host and writable SOUNDCLOUD_CACHE_DIR. Ephemeral/serverless hosting needs a durable storage adapter. The public SoundCloud profile exposes the latest 10 uploads; this account's RSS currently has no items. More than 10 new uploads between successful syncs can require RSS inclusion, an official API app or a manual full import. New projects must have all their track IDs resolved before a refresh is accepted. Public markup changes can interrupt sync; the previous successful catalog remains visible and server logs report failures. These limits are documented in README.md.
