import type { Metadata } from 'next';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { socialLinks } from '@/content/site';

export const metadata: Metadata = {
  title: 'Merch — lowerkase j',
  description: 'Future merchandise drops from lowerkase j. Follow for announcements.',
};

export default function Merch() {
  return <div className="page-shell">
    <a className="skip-link" href="#main">Skip to content</a>
    <Header current="merch" />
    <main id="main" className="merch-main">
      <section className="merch-intro" aria-labelledby="merch-title">
        <div className="merch-label micro"><span>PHYSICAL ARTIFACTS</span><span>MERCH / COMING SOON</span></div>
        <div className="merch-layout">
          <div className="merch-copy"><p className="micro muted">FROM THE ARCHIVE, INTO YOUR HANDS.</p><h1 id="merch-title">Something<br />to <em>hold on to.</em></h1><p className="merch-note">A space for future drops.<br />Nothing available just yet.</p><a className="text-link" href={socialLinks[0].url} target="_blank" rel="noopener noreferrer">Follow for drop announcements <span aria-hidden="true">↗</span></a></div>
          <span className="artifact-orbit" aria-hidden="true"><span>j</span></span>
        </div>
      </section>
    </main>
    <Footer />
  </div>;
}
