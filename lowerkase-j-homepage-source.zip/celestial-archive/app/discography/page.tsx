import type { Metadata } from 'next';
import Image from 'next/image';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { getCatalog } from '@/lib/catalog';
import CatalogRefresh from '@/components/CatalogRefresh';

export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: 'Discography — lowerkase j',
  description: 'Explore lowerkase j’s projects and tracks, with original artwork and listening links from SoundCloud.',
};
function duration(ms: number) {
  const seconds = Math.floor(ms / 1000);
  return `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}`;
}
const external = { target: '_blank', rel: 'noopener noreferrer' } as const;

export default async function Discography() {
  const catalog = await getCatalog();
  const projectTrackIds = new Set(catalog.projects.flatMap(project => project.trackIds));
  const otherTracks = catalog.tracks.filter(track => !projectTrackIds.has(track.id));
  return <div className="page-shell">
    <a className="skip-link" href="#main">Skip to content</a>
    <Header current="discography" />
    <main id="main" className="discography-main">
      <CatalogRefresh />
      <div className="discography-heading">
        <div><p className="micro muted">THE SOUND ARCHIVE</p><h1>Discography<span aria-hidden="true">.</span></h1></div>
        <a className="text-link" href={catalog.source} {...external}>Listen on SoundCloud <span aria-hidden="true">↗</span></a>
      </div>
      <section aria-labelledby="projects-title">
        <div className="catalog-label"><h2 id="projects-title" className="micro">PROJECTS</h2><span className="micro muted">{catalog.projects.length} PROJECTS / {catalog.tracks.length} TRACKS</span></div>
        <div className="project-grid">{catalog.projects.map(project => (
          <article className="release-card" key={project.id}>
            <a href={project.url} {...external} className="release-art" aria-label={`Listen to ${project.title} on SoundCloud`}>
              {project.artwork ? <Image src={project.artwork.src} alt={`${project.title} artwork from SoundCloud`} width={500} height={500} sizes="(max-width: 700px) 88vw, 30vw" /> : <span className="artwork-fallback">j</span>}
              <span className="release-arrow" aria-hidden="true">↗</span>
            </a>
            <div className="release-meta micro muted"><span>{project.type} · {project.trackIds.length} TRACKS</span><span>{(project.releaseDate ?? project.publishedAt).slice(0,4)}</span></div>
            <h3><a href={project.url} {...external}>{project.title}</a></h3>
            <details className="project-tracklist">
              <summary>Tracklist <span aria-hidden="true">+</span></summary>
              <ol>{project.trackIds.map(id => {
                const track = catalog.tracks.find(item => item.id === id)!;
                return <li key={id}><a href={track.url} {...external}><span>{track.title}</span><span className="micro muted">{duration(track.durationMs)} ↗</span></a></li>;
              })}</ol>
            </details>
          </article>
        ))}</div>
      </section>
      <section className="other-tracks" aria-labelledby="tracks-title">
        <div className="catalog-label"><h2 id="tracks-title" className="micro">MORE TRACKS</h2><span className="micro muted">{otherTracks.length} UPLOADS</span></div>
        <div className="track-grid">{otherTracks.map(track => (
          <a className="track-row" key={track.id} href={track.url} {...external}>
            {track.artwork ? <Image src={track.artwork.src} alt="" width={80} height={80} sizes="80px" /> : <span className="track-art-fallback" aria-hidden="true">j</span>}
            <span className="track-info"><span className="track-title">{track.title}</span><span className="micro muted">{track.uploadedAt.slice(0,4)} · {duration(track.durationMs)}</span></span>
            <span className="track-arrow" aria-hidden="true">↗</span>
          </a>
        ))}</div>
      </section>
      <p className="catalog-source micro muted">FROM <a href={catalog.source} {...external}>SOUNDCLOUD ↗</a> · UPDATED {new Date(catalog.importedAt).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' }).toUpperCase()}</p>
    </main>
    <Footer />
  </div>;
}
