import Image from 'next/image';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import { socialLinks, upcomingProject } from '@/content/site';

const soundcloud = socialLinks.find(link => link.name === 'SoundCloud')!;

export default function Home() {
  return <div className="page-shell">
    <a className="skip-link" href="#main">Skip to content</a>
    <Header />
    <main id="main" className="landing-main">
      <section className="entrance" aria-labelledby="artist-name">
        <div className="entrance-top micro"><span>AN INDEPENDENT WORLD</span><span>THE CELESTIAL ARCHIVE</span></div>
        <h1 id="artist-name">lowerkase j<span className="name-dot" aria-hidden="true">+</span></h1>
        <div className="hero-stage">
          <div className="hero-side hero-side-left"><span className="small-cross" aria-hidden="true">+</span><p className="micro">THE CELESTIAL<br />ARCHIVE</p><p className="hero-note">A place for<br /><em>what remains.</em></p></div>
          <figure className="hero-art">
            <div className="halo" aria-hidden="true" />
            <Image src="/artwork/snow.jpg" alt="lowerkase j with arms outstretched in pale lavender snow." width={1400} height={1400} sizes="(max-width: 700px) 88vw, (max-width: 1000px) 48vw, 440px" priority />
            <figcaption className="micro"><span>LOWERKASE J</span><span>THE CELESTIAL ARCHIVE</span></figcaption>
          </figure>
          <div className="hero-side hero-side-right"><p className="micro upcoming"><span aria-hidden="true" />{upcomingProject.status}</p><h2>{upcomingProject.title}</h2><p className="project-note">A new chapter<br />is taking shape.</p><a className="text-link" href={soundcloud.url} target="_blank" rel="noopener noreferrer">Listen on SoundCloud <span aria-hidden="true">↗</span></a></div>
        </div>
        <nav className="follow-links" aria-label="Follow lowerkase j">
          <span className="micro muted">STAY CLOSE</span>
          <div>{socialLinks.map(link => <a key={link.name} href={link.url} target="_blank" rel="noopener noreferrer">{link.name}<span aria-hidden="true">↗</span></a>)}</div>
        </nav>
      </section>
    </main>
    <Footer />
  </div>;
}
