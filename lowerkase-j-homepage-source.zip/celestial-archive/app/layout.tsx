import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'lowerkase j — The Celestial Archive',
  description: 'The official world of lowerkase j. Follow, listen, and discover future merch drops. ANGEL, an upcoming project.',
  robots: { index: false, follow: false }, // Review build; enable only after approved launch.
  openGraph: { title: 'lowerkase j — The Celestial Archive', description: 'Follow lowerkase j. Music and future merch drops.', type: 'website' },
  twitter: { card: 'summary_large_image', title: 'lowerkase j — The Celestial Archive' },
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
